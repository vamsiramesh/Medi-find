# 💊 MediFinder — Emergency Medicine Locator

> **Find medicines near you in real-time. Built for emergencies.**

MediFinder is a React-based emergency medicine locator app designed to help people quickly find critical medications during medical emergencies. Built as a hackathon submission for **HackHustle CODE KNIGHT 2026 — Healthcare Domain**.

---

## 🚀 Features

| Tab | Feature |
|-----|---------|
| 🔍 Search | Search medicines by name or category with live stock status |
| 🗺️ Map | Interactive pharmacy map with directions & contact |
| ⏱️ Golden Hour | Countdown timer tracking the critical first 60 minutes |
| 🤝 Community | Peer-to-peer medicine sharing pool |
| 📄 Rx Scan | Upload & parse prescriptions to detect medicines |
| 🚨 Emergency | One-tap emergency contacts + offline mesh SOS |

---

## 🛠️ Tech Stack

- **React 18** — UI framework
- **CSS-in-JS** — inline styles with shared design tokens (`src/styles.js`)
- **Google Fonts** — Syne (display) + Inter (body)
- No external UI library dependencies

---

## 📁 Project Structure

```
medifinder/
├── public/
│   └── index.html          # HTML shell with meta tags + global CSS reset
├── src/
│   ├── index.js            # React root entry point
│   ├── App.jsx             # App shell: header, bottom nav, tab routing
│   ├── data.js             # All mock data (medicines, pharmacies, etc.)
│   ├── styles.js           # Design tokens, keyframes, style helpers
│   └── components/
│       ├── PulseRing.jsx   # Animated live indicator dot
│       ├── SearchTab.jsx   # Medicine search with filters
│       ├── MapTab.jsx      # Pharmacy map & list
│       ├── GoldenHourTab.jsx  # Countdown timer
│       ├── CommunityTab.jsx   # Medicine sharing feed
│       ├── RxScanTab.jsx      # Prescription upload & scan
│       └── EmergencyTab.jsx   # Emergency contacts & SOS
├── package.json
└── README.md
```

---

## ⚡ Getting Started

### Prerequisites
- Node.js v16 or higher
- npm v8 or higher

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/medifinder.git
cd medifinder

# 2. Install dependencies
npm install

# 3. Start the development server
npm start
```

The app will open at **http://localhost:3000**

### Build for Production

```bash
npm run build
```

Output is in the `/build` folder — ready to deploy to Vercel, Netlify, or GitHub Pages.

---

## 🌐 Deployment

### Vercel (Recommended)
```bash
npm install -g vercel
vercel
```

### Netlify
```bash
npm run build
# Drag the /build folder into netlify.com/drop
```

### GitHub Pages
```bash
npm install gh-pages --save-dev
# Add to package.json scripts: "deploy": "gh-pages -d build"
# Add "homepage": "https://YOUR_USERNAME.github.io/medifinder"
npm run deploy
```

---

## 🗺️ Roadmap / Future Enhancements

- [ ] Google Maps API integration for real pharmacy locations
- [ ] Firebase backend for live medicine stock updates
- [ ] Community share verification system
- [ ] OCR integration for Rx scanner (Tesseract.js or Google Vision API)
- [ ] Push notifications for Golden Hour alerts
- [ ] PWA support for offline use
- [ ] Multi-language support (Hindi, Tamil, Telugu)
- [ ] Integrate with hospital APIs (ABDM / NHP)

---

## 👨‍💻 Author

Built with ❤️ for HackHustle CODE KNIGHT 2026 — Healthcare Domain.

---

## 📄 License

MIT License — free to use, modify, and distribute.
