import React, { useState, useEffect, useRef } from "react";
import { RELAY_CHAIN } from "../data";
import { COLORS, FONTS, card } from "../styles";

const TOTAL = 3600; // 60 minutes in seconds

function getPhase(pct) {
  if (pct > 60) return { label: "STABLE WINDOW",  dot: "🟢", color: COLORS.green };
  if (pct > 30) return { label: "URGENT",          dot: "🟡", color: COLORS.amber };
  return             { label: "CRITICAL",           dot: "🔴", color: COLORS.red   };
}

export default function GoldenHourTab() {
  const [seconds, setSeconds] = useState(TOTAL);
  const [running, setRunning] = useState(false);
  const [incident, setIncident] = useState("");
  const intervalRef = useRef(null);

  useEffect(() => {
    if (running && seconds > 0) {
      intervalRef.current = setInterval(() => setSeconds((s) => s - 1), 1000);
    } else {
      clearInterval(intervalRef.current);
    }
    return () => clearInterval(intervalRef.current);
  }, [running, seconds]);

  const pct   = (seconds / TOTAL) * 100;
  const phase = getPhase(pct);
  const mins  = String(Math.floor(seconds / 60)).padStart(2, "0");
  const secs  = String(seconds % 60).padStart(2, "0");

  const R = 80;
  const CIRC = 2 * Math.PI * R;
  const offset = CIRC * (1 - pct / 100);

  const reset = () => {
    setRunning(false);
    setSeconds(TOTAL);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 22 }}>

      {/* Header */}
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 13, color: COLORS.gray2, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6, fontFamily: FONTS.display }}>
          ⏱ Golden Hour Guardian
        </div>
        <div style={{ fontSize: 12, color: COLORS.gray3, maxWidth: 290, lineHeight: 1.5 }}>
          The first 60 minutes after a medical emergency are critical for survival. Start the timer immediately.
        </div>
      </div>

      {/* Incident label input */}
      <input
        value={incident}
        onChange={(e) => setIncident(e.target.value)}
        placeholder="Incident type (e.g. Heart Attack, Stroke...)"
        style={{
          width:        "100%",
          padding:      "10px 14px",
          background:   "#1a0a0a",
          border:       `1.5px solid ${COLORS.borderMid}`,
          borderRadius: 10,
          color:        COLORS.white,
          fontSize:     13,
          outline:      "none",
          transition:   "border-color .2s",
        }}
        onFocus={(e) => (e.target.style.borderColor = COLORS.red)}
        onBlur={(e)  => (e.target.style.borderColor = COLORS.borderMid)}
      />

      {/* Circular Timer */}
      <div style={{ position: "relative", width: 200, height: 200 }}>
        <svg width="200" height="200" style={{ position: "absolute", top: 0, left: 0 }}>
          {/* Track */}
          <circle cx="100" cy="100" r={R} fill="none" stroke="#1f0707" strokeWidth="10" />
          {/* Progress */}
          <circle
            cx="100" cy="100" r={R}
            fill="none"
            stroke={phase.color}
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={CIRC}
            strokeDashoffset={offset}
            style={{
              transform:       "rotate(-90deg)",
              transformOrigin: "100px 100px",
              transition:      "stroke-dashoffset .6s linear, stroke .4s ease",
              filter:          `drop-shadow(0 0 6px ${phase.color}60)`,
            }}
          />
        </svg>

        {/* Inner text */}
        <div style={{
          position:       "absolute",
          inset:          0,
          display:        "flex",
          flexDirection:  "column",
          alignItems:     "center",
          justifyContent: "center",
          gap:            4,
        }}>
          <div style={{
            fontSize:    48,
            fontWeight:  900,
            color:       phase.color,
            fontFamily:  FONTS.display,
            letterSpacing: -2,
            lineHeight:  1,
            animation:   seconds < 300 && running ? "blink 1s ease infinite" : "none",
          }}>
            {mins}:{secs}
          </div>
          <div style={{ fontSize: 11, color: COLORS.gray3 }}>
            {phase.dot} {phase.label}
          </div>
          {incident && (
            <div style={{ fontSize: 10, color: COLORS.gray4, marginTop: 2, maxWidth: 120, textAlign: "center" }}>
              {incident}
            </div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div style={{ display: "flex", gap: 10 }}>
        <button
          onClick={() => setRunning((r) => !r)}
          style={{
            padding:      "12px 30px",
            borderRadius: 12,
            fontWeight:   800,
            fontSize:     14,
            cursor:       "pointer",
            fontFamily:   FONTS.display,
            background:   running ? COLORS.bgCard : COLORS.red,
            border:       `2px solid ${running ? COLORS.borderMid : COLORS.red}`,
            color:        COLORS.white,
            transition:   "all .15s",
            boxShadow:    !running ? `0 4px 16px ${COLORS.redGlow}` : "none",
          }}
        >
          {running ? "⏸ Pause" : "▶ Start Timer"}
        </button>
        <button
          onClick={reset}
          style={{
            padding:      "12px 18px",
            borderRadius: 12,
            fontWeight:   700,
            fontSize:     14,
            cursor:       "pointer",
            fontFamily:   FONTS.display,
            background:   COLORS.bgCard,
            border:       `1.5px solid ${COLORS.border}`,
            color:        COLORS.gray2,
          }}
        >
          ↺ Reset
        </button>
      </div>

      {/* Relay Chain */}
      <div style={{ width: "100%", ...card(), paddingTop: 14 }}>
        <div style={{
          fontSize:      12,
          color:         COLORS.gray2,
          marginBottom:  10,
          textTransform: "uppercase",
          letterSpacing: 1,
          fontFamily:    FONTS.display,
        }}>
          Medicine Chain Relay
        </div>
        {RELAY_CHAIN.map((stop, i) => (
          <div
            key={i}
            style={{
              display:    "flex",
              alignItems: "center",
              gap:        10,
              padding:    "8px 0",
              borderTop:  i > 0 ? `1px solid ${COLORS.bgCardHover}` : "none",
            }}
          >
            <span style={{
              width:          22,
              height:         22,
              borderRadius:   "50%",
              background:     `${COLORS.red}20`,
              color:          COLORS.red,
              fontSize:       11,
              display:        "flex",
              alignItems:     "center",
              justifyContent: "center",
              fontWeight:     800,
              flexShrink:     0,
            }}>
              {i + 1}
            </span>
            <span style={{ fontSize: 13, color: COLORS.gray1 }}>{stop.icon} {stop.label}</span>
            <span style={{ fontSize: 12, color: COLORS.gray3, marginLeft: "auto" }}>{stop.dist}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
