import React, { useState } from "react";
import { COMMUNITY_SHARES } from "../data";
import { COLORS, FONTS, card, btn } from "../styles";

export default function CommunityTab() {
  const [shares, setShares]       = useState(COMMUNITY_SHARES);
  const [showForm, setShowForm]   = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm]           = useState({ medicine: "", qty: "", loc: "" });

  const handleRequest = (id) => {
    setShares((prev) =>
      prev.map((s) => (s.id === id ? { ...s, requested: true } : s))
    );
  };

  const handleSubmit = () => {
    if (!form.medicine || !form.qty || !form.loc) return;
    const newShare = {
      id:        Date.now(),
      user:      "You",
      avatar:    "Y",
      medicine:  form.medicine,
      qty:       form.qty,
      loc:       form.loc,
      time:      "Just now",
      requested: false,
    };
    setShares((prev) => [newShare, ...prev]);
    setSubmitted(true);
    setShowForm(false);
    setForm({ medicine: "", qty: "", loc: "" });
    setTimeout(() => setSubmitted(false), 3000);
  };

  const inputStyle = {
    width:        "100%",
    padding:      "10px 12px",
    background:   "#1a0a0a",
    border:       `1.5px solid ${COLORS.borderMid}`,
    borderRadius: 10,
    color:        COLORS.white,
    fontSize:     13,
    outline:      "none",
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>

      {/* Info Banner */}
      <div style={{
        background:   "#0a1a0a",
        border:       `1px solid #14401a`,
        borderRadius: 12,
        padding:      14,
      }}>
        <div style={{ fontSize: 12, color: COLORS.green, fontWeight: 700, marginBottom: 5, fontFamily: FONTS.display, letterSpacing: 1 }}>
          🤝 COMMUNITY MEDICINE POOL
        </div>
        <div style={{ fontSize: 12, color: COLORS.gray3, lineHeight: 1.5 }}>
          Share surplus medicines with neighbours in need during emergencies. All shares are voluntary and verified by the community.
        </div>
      </div>

      {/* Success toast */}
      {submitted && (
        <div style={{
          background:   COLORS.greenBg,
          border:       `1px solid ${COLORS.greenBorder}`,
          borderRadius: 10,
          padding:      "10px 14px",
          fontSize:     13,
          color:        COLORS.green,
          fontWeight:   700,
          animation:    "fadeIn .3s ease",
          textAlign:    "center",
        }}>
          ✓ Your medicine share has been posted!
        </div>
      )}

      {/* Share Button / Form */}
      {!showForm ? (
        <button
          onClick={() => setShowForm(true)}
          style={btn("success", { width: "100%", textAlign: "center" })}
        >
          + Share a Medicine
        </button>
      ) : (
        <div style={card({ padding: 16, borderColor: COLORS.greenBorder })}>
          <div style={{ fontSize: 13, color: COLORS.green, fontWeight: 700, marginBottom: 12, fontFamily: FONTS.display }}>
            Share Medicine
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <input
              placeholder="Medicine name (e.g. Paracetamol 500mg)"
              value={form.medicine}
              onChange={(e) => setForm({ ...form, medicine: e.target.value })}
              style={inputStyle}
            />
            <input
              placeholder="Quantity (e.g. 10 tabs, 1 unit)"
              value={form.qty}
              onChange={(e) => setForm({ ...form, qty: e.target.value })}
              style={inputStyle}
            />
            <input
              placeholder="Your location (e.g. Andheri West)"
              value={form.loc}
              onChange={(e) => setForm({ ...form, loc: e.target.value })}
              style={inputStyle}
            />
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={handleSubmit} style={btn("success", { flex: 1, padding: "10px" })}>
                ✓ Post Share
              </button>
              <button onClick={() => setShowForm(false)} style={btn("ghost", { flex: 1, padding: "10px" })}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Community Feed */}
      <div style={{ fontSize: 12, color: COLORS.gray3, textTransform: "uppercase", letterSpacing: 1, fontFamily: FONTS.display }}>
        Recent Shares ({shares.length})
      </div>

      {shares.map((s, i) => (
        <div
          key={s.id}
          style={{
            ...card(),
            animation:      "slideIn .3s ease both",
            animationDelay: `${i * 0.05}s`,
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            {/* Left */}
            <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
              {/* Avatar */}
              <div style={{
                width:          36,
                height:         36,
                borderRadius:   "50%",
                background:     `${COLORS.red}30`,
                color:          COLORS.red,
                display:        "flex",
                alignItems:     "center",
                justifyContent: "center",
                fontWeight:     800,
                fontSize:       14,
                fontFamily:     FONTS.display,
                flexShrink:     0,
              }}>
                {s.avatar}
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.white }}>{s.medicine}</div>
                <div style={{ fontSize: 12, color: COLORS.gray2, marginTop: 2 }}>{s.qty} · {s.loc}</div>
                <div style={{ fontSize: 11, color: COLORS.gray3, marginTop: 3 }}>
                  Shared by {s.user} · {s.time}
                </div>
              </div>
            </div>

            {/* Request button */}
            {s.requested ? (
              <span style={{
                fontSize:     11,
                padding:      "4px 10px",
                borderRadius: 8,
                background:   COLORS.greenBg,
                color:        COLORS.green,
                fontWeight:   700,
                border:       `1px solid ${COLORS.greenBorder}`,
                whiteSpace:   "nowrap",
              }}>
                ✓ Requested
              </span>
            ) : (
              <button
                onClick={() => handleRequest(s.id)}
                style={{
                  padding:      "5px 12px",
                  borderRadius: 8,
                  background:   COLORS.red,
                  border:       "none",
                  color:        COLORS.white,
                  fontSize:     11,
                  fontWeight:   700,
                  cursor:       "pointer",
                  fontFamily:   FONTS.display,
                  whiteSpace:   "nowrap",
                }}
              >
                Request
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
