import React, { useState } from "react";
import { MEDICINES } from "../data";
import { COLORS, FONTS, card, badge } from "../styles";

export default function SearchTab() {
  const [query, setQuery]   = useState("");
  const [filter, setFilter] = useState("all"); // all | available | low | unavailable

  const filtered = MEDICINES.filter((m) => {
    const matchQuery  = m.name.toLowerCase().includes(query.toLowerCase());
    const matchFilter = filter === "all" || m.status === filter;
    return matchQuery && matchFilter;
  });

  const filters = [
    { key: "all",         label: "All"       },
    { key: "available",   label: "✓ In Stock" },
    { key: "low",         label: "⚠ Low"      },
    { key: "unavailable", label: "✗ Out"      },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

      {/* Search Input */}
      <div style={{ position: "relative" }}>
        <span style={{
          position: "absolute", left: 14, top: "50%",
          transform: "translateY(-50%)", fontSize: 18, opacity: 0.4,
        }}>🔍</span>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search medicine name or category..."
          style={{
            width: "100%",
            padding: "14px 14px 14px 44px",
            background: "#1a0a0a",
            border: `1.5px solid ${COLORS.borderMid}`,
            borderRadius: 12,
            color: COLORS.white,
            fontSize: 15,
            outline: "none",
            transition: "border-color .2s",
          }}
          onFocus={(e)  => (e.target.style.borderColor = COLORS.red)}
          onBlur={(e)   => (e.target.style.borderColor = COLORS.borderMid)}
        />
      </div>

      {/* Filter Pills */}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            style={{
              padding:      "5px 14px",
              borderRadius: 20,
              fontSize:     12,
              fontWeight:   700,
              cursor:       "pointer",
              fontFamily:   FONTS.display,
              border:       `1.5px solid ${filter === f.key ? COLORS.red : COLORS.border}`,
              background:   filter === f.key ? COLORS.redDeep : COLORS.bgCard,
              color:        filter === f.key ? COLORS.red : COLORS.gray2,
              transition:   "all .15s",
            }}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Results count */}
      <div style={{ fontSize: 12, color: COLORS.gray3 }}>
        {filtered.length} medicine{filtered.length !== 1 ? "s" : ""} found
      </div>

      {/* Medicine Cards */}
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {filtered.length === 0 ? (
          <div style={{
            textAlign: "center", padding: "40px 20px",
            color: COLORS.gray3, fontSize: 14,
          }}>
            <div style={{ fontSize: 32, marginBottom: 10 }}>💊</div>
            No medicines match your search.
          </div>
        ) : (
          filtered.map((med, i) => {
            const { style: badgeStyle, label: badgeLabel } = badge(med.status);
            return (
              <div
                key={med.id}
                style={{
                  ...card(),
                  display:         "flex",
                  justifyContent:  "space-between",
                  alignItems:      "center",
                  gap:             12,
                  animation:       "slideIn .3s ease both",
                  animationDelay:  `${i * 0.04}s`,
                }}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{
                    fontWeight:   700,
                    fontSize:     15,
                    color:        COLORS.white,
                    fontFamily:   FONTS.display,
                    whiteSpace:   "nowrap",
                    overflow:     "hidden",
                    textOverflow: "ellipsis",
                  }}>
                    {med.name}
                  </div>
                  <div style={{ fontSize: 11, color: COLORS.gray3, marginTop: 2 }}>
                    {med.category}
                  </div>
                  <div style={{ fontSize: 12, color: COLORS.gray2, marginTop: 4 }}>
                    {med.pharmacies > 0
                      ? `${med.pharmacies} pharmacies · nearest ${med.nearest}`
                      : "Out of stock at all nearby pharmacies"}
                  </div>
                </div>
                <span style={badgeStyle}>{badgeLabel}</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
