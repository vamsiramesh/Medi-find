import React, { useState, useRef } from "react";
import { SCANNED_MEDICINES } from "../data";
import { COLORS, FONTS, card } from "../styles";

const STAGES = ["idle", "scanning", "done"];

export default function RxScanTab() {
  const [stage, setStage]   = useState("idle");
  const [fileName, setFileName] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef();

  const handleFile = (file) => {
    if (!file) return;
    setFileName(file.name);
    setStage("scanning");
    setTimeout(() => setStage("done"), 2200);
  };

  const onInputChange = (e) => handleFile(e.target.files[0]);

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    handleFile(e.dataTransfer.files[0]);
  };

  const reset = () => {
    setStage("idle");
    setFileName(null);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>

      {/* Header */}
      <div style={{ textAlign: "center" }}>
        <div style={{
          fontSize:      13,
          color:         COLORS.gray2,
          letterSpacing: 2,
          textTransform: "uppercase",
          fontFamily:    FONTS.display,
        }}>
          📄 Prescription Scanner
        </div>
        <div style={{ fontSize: 12, color: COLORS.gray3, marginTop: 4 }}>
          Upload a photo or PDF of your prescription to auto-detect medicines.
        </div>
      </div>

      {/* Drop Zone */}
      {stage === "idle" && (
        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          style={{
            border:         `2px dashed ${dragOver ? COLORS.red : COLORS.borderMid}`,
            borderRadius:   16,
            padding:        "40px 20px",
            display:        "flex",
            flexDirection:  "column",
            alignItems:     "center",
            gap:            10,
            cursor:         "pointer",
            background:     dragOver ? "#1a0404" : COLORS.bgDark,
            transition:     "all .2s",
          }}
        >
          <div style={{ fontSize: 44 }}>📄</div>
          <div style={{ fontSize: 14, color: COLORS.gray2, textAlign: "center" }}>
            Tap to upload or drag &amp; drop
          </div>
          <div style={{ fontSize: 12, color: COLORS.gray4 }}>
            JPG · PNG · PDF supported
          </div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*,.pdf"
            style={{ display: "none" }}
            onChange={onInputChange}
          />
        </div>
      )}

      {/* Scanning State */}
      {stage === "scanning" && (
        <div style={{
          ...card({ padding: "30px 20px" }),
          display:        "flex",
          flexDirection:  "column",
          alignItems:     "center",
          gap:            14,
          position:       "relative",
          overflow:       "hidden",
        }}>
          {/* Scan line animation */}
          <div style={{
            position:   "absolute",
            left:       0,
            right:      0,
            height:     2,
            background: `linear-gradient(90deg, transparent, ${COLORS.red}, transparent)`,
            animation:  "scanLine 1.2s linear infinite",
            opacity:    0.6,
          }} />
          <div style={{ fontSize: 36 }}>📄</div>
          <div style={{ fontSize: 14, color: COLORS.white, fontWeight: 700 }}>{fileName}</div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, color: COLORS.red, fontWeight: 700, fontSize: 14 }}>
            <span style={{ animation: "spin 1s linear infinite", display: "inline-block" }}>⟳</span>
            Analysing prescription...
          </div>
          <div style={{ fontSize: 12, color: COLORS.gray3 }}>
            Detecting medicine names, dosages, and quantities
          </div>
        </div>
      )}

      {/* Results State */}
      {stage === "done" && (
        <>
          <div style={{
            ...card(),
            borderColor: COLORS.greenBorder,
            background:  "#0a1208",
            animation:   "fadeIn .4s ease",
          }}>
            <div style={{ fontSize: 12, color: COLORS.gray3, marginBottom: 4 }}>
              📄 {fileName}
            </div>
            <div style={{
              fontSize:   13,
              color:      COLORS.green,
              fontWeight: 800,
              fontFamily: FONTS.display,
              marginBottom: 12,
            }}>
              ✓ {SCANNED_MEDICINES.length} Medicines Detected
            </div>

            {SCANNED_MEDICINES.map((m, i) => (
              <div
                key={i}
                style={{
                  display:        "flex",
                  justifyContent: "space-between",
                  alignItems:     "center",
                  padding:        "9px 0",
                  borderTop:      i > 0 ? `1px solid ${COLORS.bgCardHover}` : "none",
                }}
              >
                <span style={{ fontSize: 13, color: COLORS.gray1 }}>{m}</span>
                <button
                  style={{
                    padding:      "3px 12px",
                    borderRadius: 8,
                    background:   COLORS.red,
                    border:       "none",
                    color:        COLORS.white,
                    fontSize:     11,
                    fontWeight:   700,
                    cursor:       "pointer",
                    fontFamily:   FONTS.display,
                  }}
                >
                  Find →
                </button>
              </div>
            ))}
          </div>

          <button
            onClick={reset}
            style={{
              padding:      "10px",
              borderRadius: 10,
              background:   COLORS.bgCard,
              border:       `1.5px solid ${COLORS.border}`,
              color:        COLORS.gray2,
              fontSize:     13,
              fontWeight:   700,
              cursor:       "pointer",
              fontFamily:   FONTS.display,
            }}
          >
            ↺ Scan Another Prescription
          </button>
        </>
      )}

      {/* Tips */}
      <div style={card({ background: "#0a0a1a", borderColor: COLORS.blueBorder })}>
        <div style={{ fontSize: 12, color: COLORS.blueAccent, fontWeight: 700, marginBottom: 6, fontFamily: FONTS.display }}>
          💡 SCANNING TIPS
        </div>
        {[
          "Ensure the prescription is well-lit and in focus",
          "Include the doctor's name and date for verification",
          "Handwritten prescriptions may take longer to process",
        ].map((tip, i) => (
          <div key={i} style={{ fontSize: 12, color: COLORS.gray3, padding: "4px 0", display: "flex", gap: 8 }}>
            <span style={{ color: COLORS.blueAccent }}>·</span> {tip}
          </div>
        ))}
      </div>
    </div>
  );
}
