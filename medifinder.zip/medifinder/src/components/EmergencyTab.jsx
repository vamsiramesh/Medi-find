import React, { useState } from "react";
import { EMERGENCY_CONTACTS } from "../data";
import { COLORS, FONTS, card } from "../styles";

export default function EmergencyTab() {
  const [meshEnabled, setMeshEnabled] = useState(false);
  const [sos, setSos]                 = useState(false);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>

      {/* SOS Banner */}
      <div style={{
        background:   "#200505",
        border:       `1.5px solid ${COLORS.red}`,
        borderRadius: 14,
        padding:      16,
        textAlign:    "center",
        boxShadow:    `0 0 24px ${COLORS.redGlow}`,
      }}>
        <div style={{ fontSize: 28, marginBottom: 6 }}>🚨</div>
        <div style={{
          fontWeight:  900,
          fontSize:    17,
          color:       COLORS.red,
          fontFamily:  FONTS.display,
          marginBottom: 4,
        }}>
          EMERGENCY CONTACTS
        </div>
        <div style={{ fontSize: 12, color: COLORS.gray2 }}>
          Tap any card to call immediately
        </div>
      </div>

      {/* SOS Button */}
      <button
        onClick={() => { setSos(true); setTimeout(() => setSos(false), 3000); }}
        style={{
          padding:      "14px",
          borderRadius: 12,
          background:   sos ? COLORS.redDeep : COLORS.red,
          border:       `2px solid ${COLORS.red}`,
          color:        COLORS.white,
          fontWeight:   900,
          fontSize:     16,
          cursor:       "pointer",
          fontFamily:   FONTS.display,
          letterSpacing: 2,
          boxShadow:    sos ? "none" : `0 4px 20px ${COLORS.redGlow}`,
          transition:   "all .2s",
          animation:    sos ? "blink .4s ease 3" : "none",
        }}
      >
        {sos ? "📡 SOS SENT — HELP IS COMING" : "🆘 SEND SOS ALERT"}
      </button>

      {/* Contact Cards */}
      {EMERGENCY_CONTACTS.map((c, i) => (
        <a
          key={i}
          href={`tel:${c.number}`}
          style={{ textDecoration: "none" }}
        >
          <div style={{
            background:     "#140606",
            border:         `1.5px solid ${COLORS.borderMid}`,
            borderRadius:   14,
            padding:        "16px 18px",
            display:        "flex",
            justifyContent: "space-between",
            alignItems:     "center",
            cursor:         "pointer",
            transition:     "border-color .15s, background .15s",
            animation:      "slideIn .3s ease both",
            animationDelay: `${i * 0.06}s`,
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = c.color;
            e.currentTarget.style.background  = "#1a0606";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = COLORS.borderMid;
            e.currentTarget.style.background  = "#140606";
          }}
          >
            {/* Left */}
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <span style={{ fontSize: 28 }}>{c.icon}</span>
              <div>
                <div style={{
                  fontWeight: 800,
                  fontSize:   15,
                  color:      COLORS.white,
                  fontFamily: FONTS.display,
                }}>
                  {c.label}
                </div>
                <div style={{
                  fontSize:   13,
                  color:      c.color,
                  fontWeight: 700,
                  marginTop:  2,
                  fontFamily: FONTS.display,
                  letterSpacing: .5,
                }}>
                  {c.number}
                </div>
              </div>
            </div>

            {/* Call button */}
            <div style={{
              width:          40,
              height:         40,
              borderRadius:   "50%",
              background:     c.color,
              display:        "flex",
              alignItems:     "center",
              justifyContent: "center",
              fontSize:       18,
              flexShrink:     0,
              boxShadow:      `0 4px 12px ${c.color}50`,
            }}>
              📞
            </div>
          </div>
        </a>
      ))}

      {/* Offline Mesh Mode */}
      <div style={card({ background: COLORS.blueBg, borderColor: COLORS.blueBorder })}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
          <div style={{
            fontSize:   12,
            color:      COLORS.blueAccent,
            fontWeight: 700,
            fontFamily: FONTS.display,
            letterSpacing: 1,
          }}>
            🌐 OFFLINE MESH MODE
          </div>
          {/* Toggle */}
          <div
            onClick={() => setMeshEnabled((v) => !v)}
            style={{
              width:        44,
              height:       24,
              borderRadius: 12,
              background:   meshEnabled ? COLORS.blueAccent : COLORS.border,
              cursor:       "pointer",
              position:     "relative",
              transition:   "background .2s",
              flexShrink:   0,
            }}
          >
            <div style={{
              position:     "absolute",
              top:          3,
              left:         meshEnabled ? 22 : 3,
              width:        18,
              height:       18,
              borderRadius: "50%",
              background:   COLORS.white,
              transition:   "left .2s",
            }} />
          </div>
        </div>
        <div style={{ fontSize: 12, color: COLORS.gray4, lineHeight: 1.5 }}>
          {meshEnabled
            ? "✓ Mesh network active. Broadcasting your location to nearby MediFinder users."
            : "Share emergency info peer-to-peer even without mobile data or WiFi."}
        </div>
      </div>
    </div>
  );
}
