import React from "react";

/**
 * Animated pulsing ring indicator — used in the header LIVE badge.
 * @param {string} color  - hex color for both ring and dot
 * @param {number} size   - dot diameter in px (default 8)
 */
export default function PulseRing({ color = "#ef4444", size = 8 }) {
  const ring = size * 1.75;
  return (
    <span style={{ position: "relative", display: "inline-flex", alignItems: "center", justifyContent: "center", width: ring, height: ring }}>
      <span style={{
        position: "absolute",
        width: ring, height: ring,
        borderRadius: "50%",
        background: color,
        opacity: 0.25,
        animation: "pulseRing 1.6s ease-out infinite",
      }} />
      <span style={{
        width: size, height: size,
        borderRadius: "50%",
        background: color,
        zIndex: 1,
      }} />
    </span>
  );
}
