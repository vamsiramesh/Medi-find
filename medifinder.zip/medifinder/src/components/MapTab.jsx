import React, { useState } from "react";
import { PHARMACIES } from "../data";
import { COLORS, FONTS, card } from "../styles";

export default function MapTab() {
  const [selected, setSelected] = useState(null);

  const toggle = (i) => setSelected(selected === i ? null : i);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>

      {/* ── Map Canvas ───────────────────────────────────────────────── */}
      <div style={{
        position:     "relative",
        height:       230,
        borderRadius: 14,
        overflow:     "hidden",
        border:       `1.5px solid ${COLORS.borderMid}`,
        background:   "linear-gradient(135deg, #0d0404 0%, #150808 100%)",
      }}>
        {/* Grid lines */}
        {[...Array(6)].map((_, i) => (
          <div key={`h${i}`} style={{
            position: "absolute", left: 0, right: 0,
            top: `${i * 20}%`, height: 1, background: "#ffffff07",
          }} />
        ))}
        {[...Array(6)].map((_, i) => (
          <div key={`v${i}`} style={{
            position: "absolute", top: 0, bottom: 0,
            left: `${i * 20}%`, width: 1, background: "#ffffff07",
          }} />
        ))}

        {/* Road lines (decorative) */}
        <div style={{ position: "absolute", top: "45%", left: 0, right: 0, height: 2, background: "#1f0a0a" }} />
        <div style={{ position: "absolute", left: "48%", top: 0, bottom: 0, width: 2, background: "#1f0a0a" }} />

        {/* User location dot */}
        <div style={{
          position:  "absolute",
          left:      "48%",
          top:       "45%",
          transform: "translate(-50%, -50%)",
          zIndex:    10,
        }}>
          <div style={{
            width:     14,
            height:    14,
            borderRadius: "50%",
            background:   COLORS.blue,
            border:       `2.5px solid ${COLORS.white}`,
            boxShadow:    `0 0 0 6px rgba(59,130,246,0.2)`,
          }} />
        </div>

        {/* Pharmacy pins */}
        {PHARMACIES.map((ph, i) => (
          <button
            key={ph.id}
            onClick={() => toggle(i)}
            style={{
              position:   "absolute",
              left:       `${ph.x}%`,
              top:        `${ph.y}%`,
              transform:  "translate(-50%, -50%)",
              background: selected === i ? COLORS.red : ph.open ? "#7f1d1d" : "#1f2937",
              border:     `2px solid ${selected === i ? COLORS.white : ph.open ? COLORS.red : "#374151"}`,
              color:      COLORS.white,
              borderRadius: 20,
              padding:    "3px 10px",
              fontSize:   11,
              fontWeight: 700,
              cursor:     "pointer",
              fontFamily: FONTS.display,
              transition: "all .15s",
              boxShadow:  selected === i ? `0 0 14px ${COLORS.redGlow}` : "none",
              zIndex:     5,
            }}
          >
            💊 {ph.dist}
          </button>
        ))}

        {/* Map label */}
        <div style={{
          position: "absolute", bottom: 10, left: 12,
          fontSize: 11, color: "#ffffff35",
          fontFamily: FONTS.display,
        }}>
          📍 Mumbai, Maharashtra
        </div>

        {/* Legend */}
        <div style={{
          position: "absolute", bottom: 10, right: 12,
          display: "flex", gap: 8, alignItems: "center",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: COLORS.blue }} />
            <span style={{ fontSize: 10, color: "#ffffff40" }}>You</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: COLORS.red }} />
            <span style={{ fontSize: 10, color: "#ffffff40" }}>Pharmacy</span>
          </div>
        </div>
      </div>

      {/* ── Pharmacy List ─────────────────────────────────────────────── */}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {PHARMACIES.map((ph, i) => (
          <div
            key={ph.id}
            onClick={() => toggle(i)}
            style={{
              ...card({
                background:  selected === i ? COLORS.bgCardHover : COLORS.bgCard,
                border:      `1px solid ${selected === i ? COLORS.red : COLORS.border}`,
                padding:     "12px 14px",
              }),
              display:        "flex",
              justifyContent: "space-between",
              alignItems:     "center",
              cursor:         "pointer",
              transition:     "all .15s",
              animation:      "slideIn .3s ease both",
              animationDelay: `${i * 0.05}s`,
            }}
          >
            {/* Left info */}
            <div>
              <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.white }}>
                {ph.name}
              </div>
              <div style={{ fontSize: 12, color: COLORS.gray2, marginTop: 2 }}>
                {ph.dist} · Stock: {ph.stock}%
              </div>
              {selected === i && (
                <div style={{ fontSize: 12, color: COLORS.gray3, marginTop: 2 }}>
                  📞 {ph.phone}
                </div>
              )}
            </div>

            {/* Right actions */}
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
              <span style={{
                fontSize:     11,
                padding:      "2px 10px",
                borderRadius: 12,
                fontWeight:   700,
                fontFamily:   FONTS.display,
                background:   ph.open ? COLORS.greenBg : "#1a0a0a",
                color:        ph.open ? COLORS.green   : "#6b7280",
                border:       `1px solid ${ph.open ? COLORS.greenBorder : COLORS.border}`,
              }}>
                {ph.open ? "● OPEN" : "○ CLOSED"}
              </span>

              {selected === i && (
                <div style={{ display: "flex", gap: 6 }}>
                  <button
                    onClick={(e) => { e.stopPropagation(); alert(`Calling ${ph.phone}`); }}
                    style={{
                      background:   COLORS.bgCard,
                      border:       `1px solid ${COLORS.border}`,
                      color:        COLORS.gray1,
                      padding:      "4px 10px",
                      borderRadius: 8,
                      fontSize:     11,
                      fontWeight:   700,
                      cursor:       "pointer",
                    }}
                  >
                    📞 Call
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open(`https://maps.google.com/maps?q=${encodeURIComponent(ph.name + " Mumbai")}`, "_blank");
                    }}
                    style={{
                      background:   COLORS.red,
                      border:       "none",
                      color:        COLORS.white,
                      padding:      "4px 10px",
                      borderRadius: 8,
                      fontSize:     11,
                      fontWeight:   700,
                      cursor:       "pointer",
                    }}
                  >
                    Directions →
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
