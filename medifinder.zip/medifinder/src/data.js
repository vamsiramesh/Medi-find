// ─── Mock Data ────────────────────────────────────────────────────────────────
// Replace these with real API calls when integrating a backend.

export const MEDICINES = [
  { id: 1, name: "Paracetamol 500mg",   pharmacies: 7, nearest: "0.3 km", status: "available", category: "Analgesic"    },
  { id: 2, name: "Metformin 500mg",     pharmacies: 3, nearest: "1.2 km", status: "low",       category: "Antidiabetic"  },
  { id: 3, name: "Amoxicillin 250mg",   pharmacies: 0, nearest: "—",      status: "unavailable",category: "Antibiotic"   },
  { id: 4, name: "Atorvastatin 10mg",   pharmacies: 5, nearest: "0.8 km", status: "available", category: "Statin"        },
  { id: 5, name: "Losartan 50mg",       pharmacies: 1, nearest: "2.1 km", status: "low",       category: "Antihypertensive"},
  { id: 6, name: "Salbutamol Inhaler",  pharmacies: 4, nearest: "0.6 km", status: "available", category: "Bronchodilator"},
  { id: 7, name: "Pantoprazole 40mg",   pharmacies: 6, nearest: "0.5 km", status: "available", category: "Antacid"       },
  { id: 8, name: "Cetirizine 10mg",     pharmacies: 2, nearest: "1.8 km", status: "low",       category: "Antihistamine" },
  { id: 9, name: "Aspirin 75mg",        pharmacies: 0, nearest: "—",      status: "unavailable",category: "Antiplatelet" },
  { id:10, name: "Azithromycin 500mg",  pharmacies: 4, nearest: "0.9 km", status: "available", category: "Antibiotic"    },
];

export const PHARMACIES = [
  { id: 1, name: "Apollo Pharmacy",      dist: "0.3 km", open: true,  stock: 94, phone: "1800-180-1104", x: 52, y: 38 },
  { id: 2, name: "MedPlus",             dist: "0.8 km", open: true,  stock: 67, phone: "040-67772727",   x: 68, y: 55 },
  { id: 3, name: "Wellness Forever",    dist: "1.2 km", open: false, stock: 23, phone: "022-62626262",   x: 33, y: 61 },
  { id: 4, name: "Netmeds Pharma",      dist: "1.7 km", open: true,  stock: 81, phone: "044-61606060",   x: 75, y: 30 },
  { id: 5, name: "Frank Ross Pharmacy", dist: "2.1 km", open: true,  stock: 45, phone: "033-22222222",   x: 22, y: 42 },
];

export const COMMUNITY_SHARES = [
  { id: 1, user: "Priya M.",   avatar: "P", medicine: "Metformin 500mg",     qty: "10 tabs", loc: "Andheri West", time: "12 min ago", requested: false },
  { id: 2, user: "Rahul S.",   avatar: "R", medicine: "Salbutamol Inhaler",  qty: "1 unit",  loc: "Bandra East",  time: "34 min ago", requested: false },
  { id: 3, user: "Ananya K.",  avatar: "A", medicine: "Paracetamol 500mg",   qty: "6 tabs",  loc: "Juhu",         time: "1 hr ago",   requested: false },
  { id: 4, user: "Dev P.",     avatar: "D", medicine: "Pantoprazole 40mg",   qty: "5 tabs",  loc: "Malad West",   time: "2 hrs ago",  requested: false },
];

export const EMERGENCY_CONTACTS = [
  { label: "Ambulance",       number: "102",          icon: "🚑", color: "#ef4444" },
  { label: "Police",          number: "100",          icon: "🚔", color: "#3b82f6" },
  { label: "Fire Brigade",    number: "101",          icon: "🚒", color: "#f97316" },
  { label: "NDRF Helpline",   number: "011-24363260", icon: "⛑️", color: "#22c55e" },
  { label: "Poison Control",  number: "1800-116-117", icon: "☠️", color: "#a855f7" },
  { label: "Women Helpline",  number: "1091",         icon: "👩", color: "#ec4899" },
];

export const RELAY_CHAIN = [
  { label: "Apollo Hospital",    dist: "2.3 km", icon: "🏥" },
  { label: "MedPlus Pharmacy",   dist: "0.8 km", icon: "💊" },
  { label: "Wellness Forever",   dist: "1.2 km", icon: "🏪" },
];

export const SCANNED_MEDICINES = [
  "Metformin 500mg × 30",
  "Atorvastatin 10mg × 30",
  "Losartan 50mg × 15",
];
