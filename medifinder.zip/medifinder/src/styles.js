// ─── Design Tokens ────────────────────────────────────────────────────────────

export const COLORS = {
  bg:           "#080202",
  bgCard:       "#110505",
  bgCardDeep:   "#140606",
  bgCardHover:  "#1f0707",
  bgDark:       "#0d0404",

  border:       "#2a1010",
  borderMid:    "#3f1212",
  borderHover:  "#7f1d1d",

  red:          "#ef4444",
  redGlow:      "rgba(239,68,68,0.35)",
  redDim:       "#991b1b",
  redDeep:      "#200a0a",

  green:        "#22c55e",
  greenBg:      "#052a0a",
  greenBorder:  "#166534",

  amber:        "#f59e0b",
  amberBg:      "#2a1a00",
  amberBorder:  "#92400e",

  blue:         "#3b82f6",
  blueBg:       "#0a0a1a",
  blueBorder:   "#1e1b4b",
  blueAccent:   "#818cf8",

  white:        "#ffffff",
  gray1:        "#cccccc",
  gray2:        "#888888",
  gray3:        "#666666",
  gray4:        "#555555",
  gray5:        "#444444",
};

export const FONTS = {
  display: "'Syne', sans-serif",
  body:    "'Inter', sans-serif",
};

// ─── Global Keyframe Injection ─────────────────────────────────────────────────

export const GLOBAL_STYLES = `
  @keyframes pulseRing {
    0%   { transform: scale(1);   opacity: 0.25; }
    100% { transform: scale(2.8); opacity: 0;    }
  }
  @keyframes slideIn {
    from { opacity: 0; transform: translateY(14px); }
    to   { opacity: 1; transform: translateY(0);    }
  }
  @keyframes fadeIn {
    from { opacity: 0; }
    to   { opacity: 1; }
  }
  @keyframes spin {
    from { transform: rotate(0deg);   }
    to   { transform: rotate(360deg); }
  }
  @keyframes blink {
    0%, 100% { opacity: 1;   }
    50%       { opacity: 0.3; }
  }
  @keyframes scanLine {
    0%   { top: 0%;   }
    100% { top: 100%; }
  }
  * { box-sizing: border-box; }
  button { font-family: 'Inter', sans-serif; }
  input, textarea { font-family: 'Inter', sans-serif; }
  a { color: inherit; }
`;

// ─── Reusable Style Helpers ────────────────────────────────────────────────────

export const card = (extra = {}) => ({
  background:   COLORS.bgCard,
  border:       `1px solid ${COLORS.border}`,
  borderRadius: 12,
  padding:      "14px 16px",
  ...extra,
});

export const badge = (status) => {
  const map = {
    available:   { bg: COLORS.greenBg,  color: COLORS.green, border: COLORS.greenBorder, label: "✓ In Stock"  },
    low:         { bg: COLORS.amberBg,  color: COLORS.amber, border: COLORS.amberBorder, label: "⚠ Low Stock" },
    unavailable: { bg: COLORS.redDeep,  color: COLORS.red,   border: COLORS.redDim,      label: "✗ Out"       },
  };
  const s = map[status] || map.unavailable;
  return {
    style: {
      padding:      "4px 12px",
      borderRadius: 20,
      fontSize:     12,
      fontWeight:   700,
      background:   s.bg,
      color:        s.color,
      border:       `1px solid ${s.border}`,
      whiteSpace:   "nowrap",
    },
    label: s.label,
  };
};

export const btn = (variant = "primary", extra = {}) => {
  const variants = {
    primary: {
      background:   COLORS.red,
      border:       `2px solid ${COLORS.red}`,
      color:        COLORS.white,
    },
    ghost: {
      background:   COLORS.bgCard,
      border:       `1.5px solid ${COLORS.border}`,
      color:        COLORS.gray2,
    },
    success: {
      background:   COLORS.greenBg,
      border:       `1.5px solid ${COLORS.greenBorder}`,
      color:        COLORS.green,
    },
    indigo: {
      background:   "#1e1b4b",
      border:       `1px solid #3730a3`,
      color:        COLORS.blueAccent,
    },
  };
  return {
    ...variants[variant],
    padding:      "11px 22px",
    borderRadius: 12,
    fontWeight:   800,
    fontSize:     14,
    cursor:       "pointer",
    fontFamily:   FONTS.display,
    transition:   "all .15s",
    ...extra,
  };
};
