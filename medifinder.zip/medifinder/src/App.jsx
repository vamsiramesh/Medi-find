import React, { useState } from "react";
import { COLORS, FONTS, GLOBAL_STYLES } from "./styles";
import PulseRing      from "./components/PulseRing";
import SearchTab      from "./components/SearchTab";
import MapTab         from "./components/MapTab";
import GoldenHourTab  from "./components/GoldenHourTab";
import CommunityTab   from "./components/CommunityTab";
import RxScanTab      from "./components/RxScanTab";
import EmergencyTab   from "./components/EmergencyTab";

const TABS = [
  { label: "Search",       icon: "🔍", component: SearchTab      },
  { label: "Map",          icon: "🗺️",  component: MapTab         },
  { label: "Golden Hour",  icon: "⏱️",  component: GoldenHourTab  },
  { label: "Community",    icon: "🤝", component: CommunityTab   },
  { label: "Rx Scan",      icon: "📄", component: RxScanTab      },
  { label: "Emergency",    icon: "🚨", component: EmergencyTab   },
];

const MAX_WIDTH = 480;

export default function App() {
  const [activeTab, setActiveTab] = useState(0);
  const ActiveComponent = TABS[activeTab].component;

  return (
    <div style={{
      minHeight:      "100vh",
      background:     COLORS.bg,
      color:          COLORS.white,
      fontFamily:     FONTS.body,
      display:        "flex",
      flexDirection:  "column",
      alignItems:     "center",
    }}>

      {/* ── Global Styles ───────────────────────────────────────────── */}
      <style>{GLOBAL_STYLES}</style>

      {/* ── Sticky Header ───────────────────────────────────────────── */}
      <header style={{
        width:        "100%",
        maxWidth:     MAX_WIDTH,
        padding:      "18px 20px 14px",
        borderBottom: `1px solid #1f0707`,
        background:   "linear-gradient(180deg, #0f0303 0%, #080202 100%)",
        position:     "sticky",
        top:          0,
        zIndex:       100,
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>

          {/* Logo */}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 22 }}>💊</span>
              <span style={{
                fontFamily:            FONTS.display,
                fontWeight:            900,
                fontSize:              24,
                letterSpacing:         -1,
                background:            "linear-gradient(90deg, #ef4444 0%, #ff7070 100%)",
                WebkitBackgroundClip:  "text",
                WebkitTextFillColor:   "transparent",
              }}>
                MediFinder
              </span>
            </div>
            <div style={{
              fontSize:      11,
              color:         COLORS.gray4,
              marginTop:     2,
              letterSpacing: 1.5,
              fontFamily:    FONTS.display,
            }}>
              EMERGENCY MEDICINE LOCATOR
            </div>
          </div>

          {/* Live indicator */}
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <PulseRing color={COLORS.green} size={8} />
            <span style={{ fontSize: 12, color: COLORS.green, fontWeight: 700, fontFamily: FONTS.display }}>
              LIVE
            </span>
          </div>
        </div>
      </header>

      {/* ── Tab Content ─────────────────────────────────────────────── */}
      <main style={{
        width:      "100%",
        maxWidth:   MAX_WIDTH,
        padding:    "20px 16px 100px", // bottom padding for nav bar
        flex:       1,
      }}>
        <ActiveComponent />
      </main>

      {/* ── Bottom Navigation ────────────────────────────────────────── */}
      <nav style={{
        position:   "fixed",
        bottom:     0,
        left:       "50%",
        transform:  "translateX(-50%)",
        width:      "100%",
        maxWidth:   MAX_WIDTH,
        background: COLORS.bgDark,
        borderTop:  `1px solid ${COLORS.border}`,
        display:    "flex",
        padding:    "8px 4px 12px",
        zIndex:     200,
      }}>
        {TABS.map((tab, i) => {
          const isActive   = activeTab === i;
          const isEmergency = i === 5;
          return (
            <button
              key={i}
              onClick={() => setActiveTab(i)}
              style={{
                flex:           1,
                display:        "flex",
                flexDirection:  "column",
                alignItems:     "center",
                gap:            3,
                padding:        "6px 2px",
                background:     "none",
                border:         "none",
                cursor:         "pointer",
                borderRadius:   10,
                transition:     "background .15s",
              }}
            >
              <span style={{ fontSize: isEmergency ? 18 : 16 }}>{tab.icon}</span>
              <span style={{
                fontSize:      9,
                fontWeight:    isActive ? 800 : 500,
                color:         isActive ? COLORS.red : COLORS.gray5,
                fontFamily:    FONTS.display,
                letterSpacing: 0.3,
              }}>
                {tab.label.toUpperCase()}
              </span>
              {isActive && (
                <div style={{
                  width:        4,
                  height:       4,
                  borderRadius: "50%",
                  background:   COLORS.red,
                  marginTop:    -1,
                }} />
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
